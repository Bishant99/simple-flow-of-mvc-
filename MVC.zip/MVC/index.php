<?php
include 'controller/controller.php';

 $controller = new controller();

 $controller->invoke();



?>