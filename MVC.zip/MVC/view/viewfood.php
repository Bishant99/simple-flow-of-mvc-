<?php 
echo $food->name."</br>";
echo $food->price."</br>";
echo $food->description."</br>";

?>